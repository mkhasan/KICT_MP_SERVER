/*
 * snap_around_test.cpp
 *
 *  Created on: Oct 2, 2019
 *      Author: kict
 */


#include "snap_around_test/snap_around_test.h"

boost::shared_ptr<spectator::SnapAround> snapper;		// we need to get rid of these global variables later

void spectator::SnapAround::callback(const ros::TimerEvent & ) {
	ROS_INFO("hellos");
}
