/*
 * snap_around_node.cpp
 *
 *  Created on: Sep 30, 2018
 *      Author: hasan
 */




#include "ros/ros.h"
#include "std_msgs/String.h"

#include "snap_around_test/snap_around_test.h"

#include <signal.h>

using namespace std;

using namespace spectator;

extern boost::shared_ptr<spectator::SnapAround> snapper;		// we need to get rid of these global variables later

void mySigintHandler(int sig)
{
  // Do some custom action.
  // For example, publish a stop message to some other nodes.

  // All the default sigint handler does is call shutdown()



	ROS_INFO("going to terminate");

	//my_location::Finalize();


	ros::shutdown();
}



int main(int argc, char **argv) {


	ros::init(argc, argv, "snap_around_node", ros::init_options::NoSigintHandler);

	ros::NodeHandle nh;

	if( ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Debug) ) {
	   ros::console::notifyLoggerLevelsChanged();
	}

	int rc;


	signal(SIGINT, mySigintHandler);
	signal(SIGTERM, mySigintHandler);




	ros::Timer handle = nh.createTimer(ros::Duration(2.0), SnapAround::callback);

	bool flag;


	try {

		while(ros::ok()) {

			ROS_DEBUG("hello");


			ros::spinOnce();
			ros::Duration(0.1).sleep();

		}



	}

	catch (const exception &e) {
		cout << e.what() << endl;

		return -1;
	}


	return 0;

}


