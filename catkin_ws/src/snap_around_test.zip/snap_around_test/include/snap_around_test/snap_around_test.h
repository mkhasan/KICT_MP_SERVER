/*
 * snap_around_test.h
 *
 *  Created on: Oct 2, 2019
 *      Author: kict
 */

#ifndef CATKIN_WS_SRC_SNAP_AROUND_TEST_INCLUDE_SNAP_AROUND_TEST_SNAP_AROUND_TEST_H_
#define CATKIN_WS_SRC_SNAP_AROUND_TEST_INCLUDE_SNAP_AROUND_TEST_SNAP_AROUND_TEST_H_

#include "ros/ros.h"

namespace spectator {

class SnapAround {
	double stepAngle;
	double waitTimeSec;
	bool snapping;
	double originalAngle;
	double currAngle;
public:
	SnapAround(bool flag) : snapping(flag) {
	}

	bool IsSnapping() {
		return snapping;
	}
	/*
	void Snap(double stepAngle, double waitTimeSec);
	void Reset();
	bool IsSnapping();
	*/


	static void callback(const ros::TimerEvent &);



};

}		// end of namespace



#endif /* CATKIN_WS_SRC_SNAP_AROUND_TEST_INCLUDE_SNAP_AROUND_TEST_SNAP_AROUND_TEST_H_ */
