#include <sstream>
#include "ros/ros.h"
#include <tr1cpp/arm.h>
#include <tr1cpp/joint.h>

namespace tr1cpp
{
	Arm::Arm()
	{

	}

	Arm::~Arm()
	{

	}
}
