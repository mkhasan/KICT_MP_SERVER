/*
 * example1_a.cpp
 *
 *  Created on: May 11, 2018
 *      Author: usrc
 */


#include "my_location/my_location.h"

#include "my_location/gps_data.h"

#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <signal.h>
#include <string>


using namespace std;
using namespace my_location;

void mySigintHandler(int sig)
{
  // Do some custom action.
  // For example, publish a stop message to some other nodes.

  // All the default sigint handler does is call shutdown()
	ROS_INFO("going to terminate");

	my_location::Finalize();
	ros::shutdown();
}

int main(int argc, char **argv) {
	ros::init(argc, argv, "my_location_node", ros::init_options::NoSigintHandler);
	ros::NodeHandle nh;
	ros::Publisher chatter_pub = nh.advertise<my_location::gps_data>("my_location", 1000);
	ros::Rate loop_rate(500);

	if( ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Info) ) {
	   ros::console::notifyLoggerLevelsChanged();
	}

	//vector<>string addr;
	//string defaultAddr = "192.168.1.133";
	//nh.getParam("~server", defaultAddr);

	//vector<string> ids;
	string addr;
	int port;
	nh.param("server", addr, string("192.168.1.133"));
	nh.param("port", port, 5000);

	ROS_DEBUG("addr is %s port is %d", addr.c_str(), port);

	my_location::Initialize(addr.c_str(), port);

	ROS_INFO("going to start loop");

	signal(SIGINT, mySigintHandler);


	std::string info="test";
	Parser parser;

	int count=0;
	my_location::gps_data msg;
	while (ros::ok()) {
		std_msgs::String str;
		std::stringstream ss;

		my_location::GetLocationInfo(parser);

		if(parser.gga.isValid && parser.rmc.isValid) {
			string info, temp;
			parser.gga.Print(temp);
			info = temp + " / ";
			parser.rmc.Print(temp);
			info += temp;

			ss << "(Info len is " << info.length() << " index is " << count++ << ") " ;
			str.data = ss.str();

			str.data = info;

			msg.time_stamp = parser.gga.timeStamp();

			ROS_DEBUG("%s", str.data.c_str());

		}
		else {
			str.data = "Invalid data " + parser.gga.isValid ? "gga valid" : "gga invalid"
					+ parser.rmc.isValid ? "rmc valid" : "rmc invalid";

			msg.time_stamp = "invalid";
			ROS_DEBUG("%s", str.data.c_str());
		}

		msg.latitude = parser.gga.latitude();
		msg.latitude_dir = parser.gga.latDir();
		msg.longitude = parser.gga.longitude();
		msg.longitude_dir = parser.gga.longDir();
		msg.quality = parser.gga.fixQuality();
 		msg.satellite_count = parser.gga.satellitesCount();
		msg.vog = parser.rmc.VOG();
		msg.cog = parser.rmc.COG();

		//ROS_INFO("%s", msg.data.c_str());


		chatter_pub.publish(msg);
		ros::spinOnce();
		ros::Duration(0.5).sleep();
	}

	ROS_INFO("going to terminate");

	return 0;
}


