

#include "my_location/parser.h"
#include "my_location/my_location.h"

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>

#include <cstring>
#include <iostream>
#include <fcntl.h>
using namespace std;

const int MAX_ITEM = 5;


static char GlobalData[my_location::MAX_LEN] = "";
static bool quit = false;


void *receive_location_data( void *ptr );

static pthread_t thread;
static pthread_mutex_t mutex;

struct server_info {
	char *addr;
	int port;
};

int my_location::Initialize(const char * _addr, int _port) {

	static char addr[my_location::MAX_LEN];

	static server_info serverInfo;
	serverInfo.addr = addr;
	serverInfo.port = _port;

	strncpy(addr, _addr, sizeof(addr)-1 );

    int  iret;

    pthread_mutex_init(&mutex, NULL);

    quit = false;

    iret = pthread_create( &thread, NULL, receive_location_data, (void *) &serverInfo);

	 if(iret)

	 {

		 fprintf(stderr,"Error - pthread_create() return code: %d\n",iret);

		 return -1;

	 }

	return 0;
}

void my_location::Finalize() {

	quit = true;
    pthread_join( thread, NULL);

}

void my_location::GetData(char * str) {
	pthread_mutex_lock( &mutex );

	strncpy(str, GlobalData, my_location::MAX_LEN-1);
	pthread_mutex_unlock( &mutex );
}

void my_location::SetData(const char *data) {
	pthread_mutex_lock( &mutex );

	strncpy(GlobalData, data, my_location::MAX_LEN-1);
	pthread_mutex_unlock( &mutex );
}


void my_location::GetLocationInfo(my_location::Parser & parser) {



	char str[my_location::MAX_LEN];
	string sentence[MAX_ITEM];


	GetData(str);

	int len = strlen(str);

	parser.gga.isValid = false;
	parser.rmc.isValid = false;



    if (len > 0 && len < my_location::MAX_LEN-1) {


    	//cout << str << endl;

		char *token = std::strtok(str, "\n");

		int i;
		for(i=0; i<MAX_ITEM && token != NULL; i++) {

			//cout << (string) token  << endl;
			sentence[i] = (string) token;


			token = std::strtok(NULL, "\n");
		}


		for (int k=0; k<i; k++) {
			if(sentence[k].length() > 0) {
				if(parser.gga.isValid == false) {
					auto ret = parser.PerseGGA(sentence[k]);
					if (ret == 0) {
						parser.gga.isValid = true;

					}

					continue;
				}

				if(parser.rmc.isValid == false) {

					auto ret = parser.PerseRMC(sentence[k]);
					if (ret == 0) {
						parser.rmc.isValid = true;
						return;
					}

				}
			}
		}
    }
}

void *receive_location_data( void *ptr ) {

	server_info *pInfo = (server_info *) ptr;
	char * addr = pInfo->addr;
	int port = pInfo->port;

    int sockfd = 0, n = 0;
    char recvBuff[1024];
    struct sockaddr_in serv_addr;

    const unsigned long sleepUs = 1000000;	// 100 ms
    const unsigned long timeout = 5000; 	// in ms
    const int MAX_WAIT = timeout*1000/sleepUs;

    memset(recvBuff, '0',sizeof(recvBuff));

    memset(&serv_addr, '0', sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);

    if(inet_pton(AF_INET, addr, &serv_addr.sin_addr)<=0)
    {
        printf("\n inet_pton error occured\n");
        return NULL;
    }

    //close(sockfd);

    char str[my_location::MAX_LEN+1];
    //char *token = std::strtok(input, ",");

    int i, length, flags;

    int waiting = 0;
    bool connected = false;

    while (quit == false)
    {

    	while(quit == false && connected == false) {
    	    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    	    {
    	        printf("\n Error : Could not create socket \n");
    	        return NULL;
    	    }

			if( connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
			{
			   printf("\n Error : Connect Failed %d\n", waiting ++);
			   close(sockfd);
			   //return NULL;
			}
			else {
				printf("\n Connected to GPS \n");
				connected = true;
				waiting = 0;

			}
			usleep(sleepUs*2);
    	}


		if(my_location::IsReqReady(sockfd)) {
					            //written = pBuffer->Receive(sockfd);

			flags = fcntl(sockfd, F_GETFL, 0);
			fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);



			n = read(sockfd, recvBuff, sizeof(recvBuff)-1);

			//cout << "read count is " << n << endl;

			if(n > 0) {
		        recvBuff[n] = 0;

		        my_location::SetData(recvBuff);

			}


			waiting = 0;

		}

		else {

			waiting ++;
		}

		//cout << "waiting " << waiting << endl;
		usleep(sleepUs);

		if(waiting == MAX_WAIT) {
			close(sockfd);
			connected = false;
			waiting = 0;
		}





    }

    close(sockfd);
    return 0;
}


bool my_location::IsReqReady(int sockfd)
{

    /// Got here because iSelectReturn > 0 thus data available on at least one descriptor
    // Is our socket in the return list of readable sockets
    bool             res;
    fd_set          sready;
    struct timeval  nowait;

    FD_ZERO(&sready);
    FD_SET((unsigned int)sockfd,&sready);
    //bzero((char *)&nowait,sizeof(nowait));
    memset((char *)&nowait,0,sizeof(nowait));

    res = select(sockfd+1,&sready,NULL,NULL,&nowait);
    if( FD_ISSET(sockfd,&sready) )
        res = true;
    else
        res = false;


    return res;

}
