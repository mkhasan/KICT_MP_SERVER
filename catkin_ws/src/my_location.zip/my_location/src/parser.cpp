/*
 * Parser.cpp
 *
 *  Created on: Nov 22, 2018
 *      Author: kict
 */



#include "my_location/parser.h"

#include <sstream>
#include <stdio.h>
#include <exception>
#include <cstring>
#include <iostream>

using namespace std;


my_location::GPS_Data::GPS_Data(const std::string & _msgID) : msgID(_msgID), isValid(false) {

	for (int i=0; i<MAX_FIELDS; i++)
		valueSet[i] = NULL;

}

void my_location::GPS_Data::Print() const{

	stringstream ss;
	for (int i=0; i<MAX_FIELDS; i++) {


		if(valueSet[i] != NULL) {
			valueSet[i]->Print(ss) << SEPARATOR;

		}
	}

	cout << ss.str();
}

void my_location::GPS_Data::Print(string & str) const{

	stringstream ss;
	for (int i=0; i<MAX_FIELDS; i++) {
		if(valueSet[i] != NULL)
			valueSet[i]->Print(ss) << SEPARATOR;
	}

	//cout << ss.str() << "\n";
	str = ss.str();
}


int my_location::GPS_Data::Parse(const string & str){		// return -2 for invalid argument, -1 for invalid msgID
												// and the position index for error in that particular position
												// 0 for success
	if(str.length() > MAX_LEN)
		return -2;

	char gnID[MAX_LEN];
	char input[MAX_LEN+1];

	strcpy(gnID, msgID.c_str());
	gnID[2] = 'N';


	strcpy(input, str.c_str());

	//static char test[255] = "hello";
	//char *test = input;

	//cout << "I am " << str << endl;



	char *token = std::strtok(input, ",");


	string temp = "$GNGGA: 0 $GNGGA,080030.40,3623.60693515,N,12724.05116854,E,1,13,2.6,66.270,M,25.112,M,,*4C";

	//cout << (string) gnID << "temp len is " << strlen(temp.c_str()) << " str len is " << strlen(str.c_str()) << endl;

	//static int count=0;
	//cout << count++ << " : " << string(str) << endl;

	int i;


	for(i=0; token != NULL && i<MAX_FIELDS; i++) {

		if(i==0) {
			if(!(string(token) == msgID || strcmp(gnID, token) == 0))
				return -1;
		}
		else {

			try {
				if(valueSet[i] != NULL)
					valueSet[i]->SetVal(string(token));

			}
			catch (const exception & e){

				return i;
			}
		}


		//cout << "token: " <<  token << endl;
		token = std::strtok(NULL, ",");
		//cout << string(token) << endl;


	}

	if (i < MAX_FIELDS)
		return MAX_FIELDS;

	isValid = true;
	return 0;
}

my_location::GGA::GGA():GPS_Data("$GPGGA") {


	valueSet[FIELD_TIME_STAMP] = (Val*) &timeStamp;
	valueSet[FIELD_LAT] = (Val*) &latitude;
	valueSet[FIELD_LAT_DIR] = (Val*) &latDir;
	valueSet[FILED_LONG] = (Val*) &longitude;
	valueSet[FILED_LONG_DIR] = (Val*) &longDir;
	valueSet[FIELD_FIX_QUALITY] = (Val*) &fixQuality;
	valueSet[FIELD_SAT_COUNT] = (Val*) &satellitesCount;

	timeStamp.SetVal("055012.00");
	latitude.SetVal("3623.57649731");
	latDir.SetVal("N");
	longitude.SetVal("12723.92253182");
	longDir.SetVal("E");
	fixQuality.SetVal("1");
	satellitesCount.SetVal("3");




}

my_location::RMC::RMC():GPS_Data("$GPRMC") {


	valueSet[FIELD_TIME_STAMP] = (Val*) &timeStamp;
	valueSet[FIELD_STATUS] = (Val*) &status;
	valueSet[FIELD_LAT] = (Val*) &latitude;
	valueSet[FIELD_LAT_DIR] = (Val*) &latDir;
	valueSet[FILED_LONG] = (Val*) &longitude;
	valueSet[FILED_LONG_DIR] = (Val*) &longDir;
	valueSet[FILED_VOG] = (Val*) &VOG;
	valueSet[FILED_COG] = (Val*) &COG;

	timeStamp.SetVal("055012.00");
	status.SetVal("A");
	latitude.SetVal("3623.57649731");
	latDir.SetVal("N");
	longitude.SetVal("12723.92253182");
	longDir.SetVal("E");
	VOG.SetVal("0.133");
	COG.SetVal("1.87");

}


int my_location::Parser::PerseGGA(const string & str){

	return gga.Parse(str);
}

int my_location::Parser::PerseRMC(const string & str){

	return rmc.Parse(str);
}
