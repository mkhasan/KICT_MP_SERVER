/*
 * parser.h
 *
 *  Created on: Nov 21, 2018
 *      Author: Hasan
 */

#ifndef GPS_TEST_SRC_PARSER_H_
#define GPS_TEST_SRC_PARSER_H_

#include <string>
#include <type_traits>
#include <string.h>

#include <sstream>
#include <iomanip>

namespace my_location {

const int MAX_FIELDS = 12;
const int MAX_LEN = 255;
const std::string SEPARATOR = " ";


class Val {
public:
	virtual void SetVal(const std::string & valStr) = 0;
	virtual std::stringstream & Print(std::stringstream & ss) const = 0;

};


template <class myType>
class TypedVal: public Val {

	myType val;
public:

	TypedVal() {};
	/*
	TypedVal(const myType &_val) {
		val = _val;
	}
	*/

	void StrToVal(const std::string & valStr, char &_val) {
		_val =  valStr.at(0);
	}


	void StrToVal(const std::string & valStr, int &_val) {
		_val =  std::stoi(valStr);
	}


	void StrToVal(const std::string & valStr, double &_val) {
		_val = std::stod(valStr);
	}

	void StrToVal(const std::string & valStr, std::string &_val) {
		_val = valStr;
	}



	void SetVal(const std::string & valStr) {

		StrToVal(valStr, val);

	}


	myType operator()() const {
		return val;
	}

	std::stringstream & Print(std::stringstream & ss) const{
		ss << val;
		return ss;
	}
};


class GPS_Data {

public:

	const std::string msgID;

	bool isValid;
	Val * valueSet[MAX_FIELDS];

	GPS_Data(const std::string & msgID);

	virtual int Parse(const std::string & str);
	virtual void Print() const;
	virtual void Print(std::string & str) const;



};

class GGA: public GPS_Data {


public:

	static const int FIELD_TIME_STAMP = 1;
	static const int FIELD_LAT = 2;
	static const int FIELD_LAT_DIR = 3;
	static const int FILED_LONG = 4;
	static const int FILED_LONG_DIR = 5;
	static const int FIELD_FIX_QUALITY = 6;
	static const int FIELD_SAT_COUNT = 7;

	TypedVal<std::string> timeStamp;	// send all
	TypedVal<std::string> latitude;
	TypedVal<char> latDir;
	TypedVal<std::string> longitude;
	TypedVal<char> longDir;
	TypedVal<int> fixQuality;
	TypedVal<int> satellitesCount;

public:

	GGA();

	//int Parse(const std::string & str);
};

class RMC : public GPS_Data{

public:

	static const int FIELD_TIME_STAMP = 1;
	static const int FIELD_STATUS = 2;
	static const int FIELD_LAT = 3;
	static const int FIELD_LAT_DIR = 4;
	static const int FILED_LONG = 5;
	static const int FILED_LONG_DIR = 6;
	static const int FILED_VOG = 7;
	static const int FILED_COG = 8;


	TypedVal<std::string> timeStamp;	// Send  VOG and COG
	TypedVal<char> status;
	TypedVal<std::string> latitude;
	TypedVal<char> latDir;
	TypedVal<std::string> longitude;
	TypedVal<char> longDir;
	TypedVal<double> VOG;
	TypedVal<double> COG;

public:

	RMC();

};


class Parser {

public:
	GGA gga;
	RMC rmc;

	Parser() {};
	int PerseGGA(const std::string & str);
	int PerseRMC(const std::string & str);



};

}	// end of namespace


#endif /* GPS_TEST_SRC_PARSER_H_ */
