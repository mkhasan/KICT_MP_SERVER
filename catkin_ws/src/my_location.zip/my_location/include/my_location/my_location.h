/*
 * my_location.h
 *
 *  Created on: Nov 24, 2018
 *      Author: usrc
 */

#ifndef CATKIN_WS_SRC_MY_LOCATION_INCLUDE_MY_LOCATION_MY_LOCATION_H_
#define CATKIN_WS_SRC_MY_LOCATION_INCLUDE_MY_LOCATION_MY_LOCATION_H_

#include "my_location/parser.h"

#include <string>



namespace my_location {

const int PORT = 5017;

int Initialize(const char * addr, int port=PORT);

void GetData(char * str);
void GetLocationInfo(Parser &parser);
void SetData(const char *data);



void Finalize();

bool IsReqReady(int sockfd);
}	// end of namespace my_location



#endif /* CATKIN_WS_SRC_MY_LOCATION_INCLUDE_MY_LOCATION_MY_LOCATION_H_ */
