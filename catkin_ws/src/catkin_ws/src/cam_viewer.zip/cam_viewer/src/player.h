/*
 * player.h
 *
 *  Created on: Dec 12, 2018
 *      Author: kict
 */

#ifndef IMAGE_PROCESSOR_SRC_PLAYER_H_
#define IMAGE_PROCESSOR_SRC_PLAYER_H_


#include <client_interface/shm_data.h>

#include <semaphore.h>



#ifdef __cplusplus
extern "C" {
#endif

int play(struct shm_data * p, sem_t *mutex, int _id);

#ifdef __cplusplus
}
#endif



#endif /* IMAGE_PROCESSOR_SRC_PLAYER_H_ */
