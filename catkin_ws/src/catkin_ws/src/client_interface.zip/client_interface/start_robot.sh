#~/bin/bash
roslaunch my_location my_location.launch
