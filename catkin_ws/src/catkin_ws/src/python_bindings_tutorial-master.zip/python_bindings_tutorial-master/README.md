# python_bindings_tutorial
Files for the Python bindings tutorial for ROS

cf. http://wiki.ros.org/ROS/Tutorials/Using%20a%20C%2B%2B%20class%20in%20Python

