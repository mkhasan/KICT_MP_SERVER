
#include "client_interface/shm_manager.h"

#include "ros/ros.h"
#include "std_msgs/String.h"

#include <iostream>
#include <sstream>
#include <string>

#define MAX_PROCESS client_interface::ShmManager::MAX_NUM_CAMERA
unsigned int pid[MAX_PROCESS];

using namespace std;
const string child = "image_processor";

string GetEnv( const string & var ) {
     const char * val = ::getenv( var.c_str() );
     if ( val == 0 ) {
         return "";
     }
     else {
         return val;
     }
}


void mySigintHandler(int sig)
{


	ros::shutdown();
}


int main(int argc, char **argv) {

	ros::init(argc, argv, "robot_node", ros::init_options::NoSigintHandler);
	ros::NodeHandle n;

	int delay_on_start;

	signal(SIGTERM, mySigintHandler);
	signal(SIGINT, mySigintHandler);          // caught in a different way fo$
	signal(SIGHUP, mySigintHandler);
	signal(SIGKILL, mySigintHandler);
	signal(SIGTSTP, mySigintHandler);


	if( ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Debug) ) {
	   ros::console::notifyLoggerLevelsChanged();
	}



	while (ros::ok()) {

		ROS_DEBUG("ROBOT ...");
		ros::spinOnce();

		ros::Duration(1.0).sleep();
	}




	return 0;
}


