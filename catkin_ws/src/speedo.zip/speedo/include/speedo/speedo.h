/*
 * speedo.h
 *
 *  Created on: Feb 10, 2019
 *      Author: usrc
 */

#ifndef CATKIN_WS_SRC_SPEEDO_INCLUDE_SPEEDO_SPEEDO_H_
#define CATKIN_WS_SRC_SPEEDO_INCLUDE_SPEEDO_SPEEDO_H_


#include <boost/scoped_ptr.hpp>

#include <ros/ros.h>


#define SPEEDO_IP "192.168.0.60"
#define SPEEDO_PORT 10001

#define THROW(exceptionClass, message) throw exceptionClass(__FILE__, \
__LINE__, (message) )

namespace speedo {


class Speedo
{
public:

	enum {MAX_LEN = 255};
	ros::NodeHandle &nh;
	bool quit;
	pthread_t thread;
	bool connected;
	bool reqConnect;
public:


	Speedo(ros::NodeHandle &nh);


	~Speedo();


};


class SpeedoException : public std::exception
{
  // Disable copy constructors
	SpeedoException& operator=(const SpeedoException&);
	std::string file_;
	int line_;
	std::string e_what_;
	int errno_;
public:
	explicit SpeedoException (std::string file, int line, int errnum)
    : file_(file), line_(line), errno_(errnum) {
      std::stringstream ss;
#if defined(_WIN32) && !defined(__MINGW32__)
      char error_str [1024];
      strerror_s(error_str, 1024, errnum);
#else
      char * error_str = strerror(errnum);
#endif
      ss << "Speedo Exception (" << errno_ << "): " << error_str;
      ss << ", file " << file_ << ", line " << line_ << ".";
      e_what_ = ss.str();
	}
	explicit SpeedoException (std::string file, int line, const char * description)
		: file_(file), line_(line), errno_(0) {
		std::stringstream ss;
		ss << "Speedo Exception: " << description;
		ss << ", file " << file_ << ", line " << line_ << ".";
		e_what_ = ss.str();
	}
	virtual ~SpeedoException() throw() {}
	SpeedoException (const SpeedoException& other) : line_(other.line_), e_what_(other.e_what_), errno_(other.errno_) {}

	int getErrorNumber () const { return errno_; }

	virtual const char* what () const throw () {
		return e_what_.c_str();
	}
};

}



#endif /* CATKIN_WS_SRC_SPEEDO_INCLUDE_SPEEDO_SPEEDO_H_ */
