#include "ros/ros.h"
#include "std_msgs/String.h"

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <fcntl.h>

#include "speedo/speedo.h"

#include <string>

using namespace std;
namespace speedo {

struct server_info {
	char *addr;
	int port;
	bool *quit;
	bool *connected;
	bool * reqConnect;
};

void *receive_location_data( void *ptr );
void *ping_thread(void *ptr);


static pthread_mutex_t mutex;


Speedo::Speedo(ros::NodeHandle& _nh)
	: nh(_nh), quit(false), thread(NULL), connected(false), reqConnect(false)
{


	static char addr[Speedo::MAX_LEN];

	static server_info serverInfo;
	serverInfo.addr = addr;
	serverInfo.port = SPEEDO_PORT;
	serverInfo.quit = &quit;
	serverInfo.connected = &connected;
	serverInfo.reqConnect = &reqConnect;


	strncpy(addr, SPEEDO_IP, sizeof(addr) );

    int  iret;

    pthread_mutex_init(&mutex, NULL);

    quit = false;

    iret = pthread_create( &thread, NULL, receive_location_data, (void *) &serverInfo);

	 if(iret)

	 {

		 static char error[MAX_LEN];
		 sprintf(error, "Error - pthread_create() return code: %d",iret);

		 THROW(SpeedoException, error);

	 }


	return;

}


Speedo::~Speedo() {

	quit = true;
	pthread_join(thread, NULL);
}

void *receive_location_data( void *ptr ) {


	pthread_t tID;

	server_info * serverInfo = (server_info *) ptr;

	while(*serverInfo->quit == false) {

		ROS_DEBUG("wOR");
		usleep(1000000);
	}

	return NULL;
}


}

