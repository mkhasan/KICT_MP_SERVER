
#include "speedo/speedo.h"

#include "spectator/get_str.h"

#include <iostream>

using namespace std;
using namespace speedo;

boost::shared_ptr<Speedo> _speedo;

bool connect(spectator::get_str::Request &req, spectator::get_str::Response &resp) {

	ROS_DEBUG("Got a call");
	resp.str = "connected";
	return true;
}

int main(int argc, char * argv[]) {
	ros::init(argc, argv, "speedo_node", ros::init_options::NoSigintHandler);

	ros::NodeHandle nh;

	if( ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Debug) ) {
	           ros::console::notifyLoggerLevelsChanged();
	}



	try {

		_speedo.reset(new Speedo(nh));

	}
	catch (const exception &e) {



		ROS_ERROR("Erorror is %s", e.what());
	}

	ros::ServiceServer service = nh.advertiseService("speedo_node/connect", connect);

	ROS_DEBUG("hELLO");

	ros::spin();
	return 0;
}
